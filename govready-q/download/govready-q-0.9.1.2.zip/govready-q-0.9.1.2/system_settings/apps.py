from django.apps import AppConfig


class SystemSettingsConfig(AppConfig):
    name = 'system_settings'
