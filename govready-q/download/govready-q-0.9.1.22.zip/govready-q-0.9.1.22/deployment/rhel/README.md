# README

See [Deploying Q to Red Hat Enterprise Linux 7 / CentOS 7 / Amazon Linux 2](https://govready-q.readthedocs.io/en/latest/deploy_rhel7_centos7.html) for detailed instructions.
