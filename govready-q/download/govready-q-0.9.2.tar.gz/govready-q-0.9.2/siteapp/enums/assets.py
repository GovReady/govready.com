from siteapp.enums.base import BaseEnum


class AssetTypeEnum(BaseEnum):
    SSP_EXPORT = "SSP Export"
