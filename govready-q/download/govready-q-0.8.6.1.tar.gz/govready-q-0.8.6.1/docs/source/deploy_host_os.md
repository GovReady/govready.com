# Installing GovReady-Q on the Host OS

.. toctree::
   :maxdepth: 2
   :caption: In This Section:

   deploy_rhel7_centos7.md
   deploy_ubuntu.md
   deploy_generic_unix.md
