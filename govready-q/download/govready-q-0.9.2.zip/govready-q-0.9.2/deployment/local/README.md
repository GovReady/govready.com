# README

See [Installing GovReady-Q Compliance Server on Workstations for Development](https://govready-q.readthedocs.io/en/latest/deploy_local_dev.html) for detailed instructions.