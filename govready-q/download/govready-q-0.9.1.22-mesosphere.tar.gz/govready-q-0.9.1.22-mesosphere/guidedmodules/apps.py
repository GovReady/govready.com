from django.apps import AppConfig


class GuidedmodulesConfig(AppConfig):
    name = 'guidedmodules'
