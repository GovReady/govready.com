immutable history
computational stuff isn't in db, lazy loaded b/c __
but can be from api
optimized for other things
