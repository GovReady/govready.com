README

Default directory for collecting static files in production deployments.
