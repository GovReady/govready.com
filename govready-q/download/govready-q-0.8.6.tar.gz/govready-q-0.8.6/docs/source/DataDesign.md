Data Design Guide
=================

The documents in this section describe GovReady-Q's database design.

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   DataDesign_siteapp.md
   DataDesign_guidedmodules.md
   DataDesign_discussion.md
   DataDesign_tools.md
