# README

See [Deploying GovReady-Q to Ubuntu Linux](https://govready-q.readthedocs.io/en/latest/deploy_ubuntu.html) for detailed instructions.



